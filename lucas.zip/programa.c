#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define P 20

struct Lista_t{
	char *palavra;
	int linha;
	struct Lista_t *prox;
};
typedef struct Lista_t Lista;

struct Hash_t{
		Lista *list;
		//struct Hash_t *prox; //usa array
	};
typedef struct Hash_t hash;

void busca(FILE *arquivo,char *palavra);

int main(){

	char *name = (char *) malloc(sizeof(char)*P);
	char *palavra = (char *) malloc(sizeof(char)*P);

	printf("Nome do arquivo: ");
	setbuf(stdin,NULL);
	fgets(name,P,stdin);

	int tam = strlen(name)-1;

	name[tam] = '\0';
	strcat(name,".txt");

	printf("%d\n",tam);

	FILE *arquivo  = fopen(name,"rt");
	if(arquivo==NULL){
		printf("O arquivo não pode ser aberto!\n");
		return 0;
	}

	printf("Digite a palavra: ");
	setbuf(stdin,NULL);
	fgets(palavra,P,stdin);

	tam = strlen(palavra)-1;

	palavra[tam] = '\0';

	busca(arquivo,palavra);
}
void busca(FILE *arquivo,char *palavra){
	
	char *search = (char *) malloc(sizeof(char)*P);


	int cont = 1;

	while(fscanf(arquivo,"%s\n",search)!=EOF){

		if(strcmp(search,palavra)==0){
			printf("Achou na linha: %d\n",cont);
		}

		fseek(arquivo, -1, SEEK_CUR);

		if(fgetc(arquivo) == '\n'){
			cont++;
		}

	}

}